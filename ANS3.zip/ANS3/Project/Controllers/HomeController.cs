using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Project.Models;
using DAL;
using BOL;
namespace Project.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<Softdrink> alldrink=DBManager.Get();
        ViewData["alldrinks"]=alldrink;
        return View();
    }
    [HttpGet]
    public IActionResult Insert()
    {

        return View();
    }
    [HttpPost]
    public IActionResult Insert(int ID, string NAME, int RATE)
    {
        DBManager.Insert(ID, NAME, RATE);
        return View();
    }

}
