namespace DAL;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    public static string constring = @"server=localhost;port=3306;user=root;password=Galaxy@j2;database=db1";
    public static void Insert(int ID, string NAME, int RATE){
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = constring;
        string query = "insert into softdrink values(@ID, @NAME, @RATE)";
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@ID", ID);
        command.Parameters.AddWithValue("@NAME", NAME);
        command.Parameters.AddWithValue("@RATE", RATE);
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();
    }
    public static List<Softdrink> Get()
    {
        List<Softdrink> l=new List<Softdrink>();
        MySqlConnection connnection=new MySqlConnection();
        connnection.ConnectionString=constring;
        string query="select * from softdrink";
        MySqlCommand command=new MySqlCommand(query,connnection);
        connnection.Open();
        MySqlDataReader reader=command.ExecuteReader();
        while(reader.Read())
        {
            int ID=int.Parse(reader["ID"].ToString());
            string NAME=(reader["NAME"].ToString());
            int RATE=int.Parse(reader["RATE"].ToString());
            l.Add(new Softdrink(ID,NAME,RATE));
        }
        reader.Close();
        connnection.Close();
        return l;
    }
}