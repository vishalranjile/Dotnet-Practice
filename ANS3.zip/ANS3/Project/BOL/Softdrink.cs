namespace BOL;
public class Softdrink
{
    public int ID { get; set; }
    public string NAME { get; set; }
    public int RATE { get; set; }
    public Softdrink(int ID, string NAME, int RATE){
        this.ID = ID;
        this.NAME = NAME;
        this.RATE = RATE;
    }
}