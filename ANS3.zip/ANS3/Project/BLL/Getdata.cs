namespace BLL;
using BOL;
using DAL;
public class Getdata
{
    public List <Softdrink> Get()
    {
        List<Softdrink> s=new List<Softdrink>();
        s=DBManager.Get();
        return s;
    }
    

}
